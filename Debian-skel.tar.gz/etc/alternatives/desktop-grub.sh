WALLPAPER=/usr/share/images/desktop-base/Drachenschatten_1024p.png
COLOR_NORMAL=blue/black
COLOR_HIGHLIGHT=black/light-grey
