#!/bin/bash

# setup postfix to send root-mails to hostmaster@eb8.org
#
# 
# 1. install postfix as sattelite system
#    mail-relay: mail.eb8.org:587
#    root-alias: hostmaster@eb8.org
# 2. run this script
#    creates ssl-certs & dh_xxxx files for postfix-config to use with TLS
#    expands main.cf with TLS config



mkdir -p /etc/ssl/private

openssl req -new -x509 -days 3650 -nodes -out /etc/ssl/certs/certs.pem -keyout /etc/ssl/private/private.key

cd /etc/postfix
openssl dhparam -out dh512.tmp 512 && mv dh512.tmp dh512.pem 
openssl dhparam -out dh2048.tmp 2048 && mv dh2048.tmp dh2048.pem 


service postfix reload
exit 0
cat << EOF >> main.cf


# TLS parameters
smtpd_tls_cert_file=/etc/ssl/certs/certs.pem
smtpd_tls_key_file=/etc/ssl/private/private.key
smtpd_use_tls=yes
smtpd_tls_auth_only = yes
smtpd_starttls_timeout = 300s
smtpd_timeout = 300s
smtpd_tls_mandatory_protocols = !SSLv2,!SSLv3
smtpd_tls_protocols =
smtpd_tls_exclude_ciphers = RC4, aNULL
smtpd_tls_session_cache_database = btree:${data_directory}/smtpd_scache
smtp_tls_session_cache_database = btree:${data_directory}/smtp_scache

# EDH config
smtpd_tls_dh1024_param_file = /etc/postfix/dh_2048.pem
smtpd_tls_dh512_param_file = /etc/postfix/dh_512.pem

# use the Postfix SMTP server's cipher preference order instead of the remote client's cipher preference order.
tls_preempt_cipherlist = yes

# The Postfix SMTP server security grade for ephemeral elliptic-curve Diffie-Hellman (EECDH) key exchange
smtpd_tls_eecdh_grade = strong

# tls logging
smtp_tls_loglevel = 0
smtpd_tls_loglevel = 0

# smtp client
smtp_tls_security_level = may
smtp_tls_mandatory_protocols = !SSLv2,!SSLv3
smtp_tls_protocols = !SSLv2,!SSLv3
smtp_tls_exclude_ciphers = RC4, aNULL

EOF


service postfix reload
