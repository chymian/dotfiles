TODO
----

* Fix prompt compatibility with zsh promptinit; if "prompt drybjed" is not run
  at startup, prompt might be messed up.

* git sometimes shows commits out of order, which messes up last commit
  display in zsh prompt. But it looks we cannot do anything about that.
